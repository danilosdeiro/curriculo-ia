# 🚀 Como publicar o CurrículoIA no Vercel (passo a passo)

Não precisa saber programar. Siga cada etapa com calma.

---

## Passo 1 — Criar conta no GitHub (gratuito)

1. Acesse: https://github.com
2. Clique em **"Sign up"**
3. Crie sua conta com e-mail e senha
4. Confirme o e-mail

---

## Passo 2 — Criar o repositório no GitHub

1. Após entrar no GitHub, clique no botão **"+"** no canto superior direito
2. Clique em **"New repository"**
3. Nome: `curriculo-ia`
4. Deixe como **Public**
5. Clique em **"Create repository"**

---

## Passo 3 — Enviar os arquivos

Você vai criar os arquivos exatamente como estão abaixo.
No GitHub, dentro do repositório criado, clique em **"creating a new file"**.

### Arquivos para criar (copie e cole o conteúdo de cada um):

```
curriculo-ia/
├── index.html
├── package.json
├── vite.config.js
├── vercel.json
└── src/
    ├── main.jsx
    ├── index.css
    ├── App.jsx
    └── pages/
        ├── Landing.jsx
        ├── Cadastro.jsx
        ├── Busca.jsx
        └── Dashboard.jsx
    └── components/
        └── CartaoVaga.jsx
```

Para criar uma pasta no GitHub:
- No campo do nome do arquivo, escreva: `src/main.jsx`
- Isso cria a pasta `src` automaticamente

---

## Passo 4 — Criar conta no Vercel (gratuito)

1. Acesse: https://vercel.com
2. Clique em **"Sign Up"**
3. Escolha **"Continue with GitHub"** (conecta automaticamente)
4. Autorize o acesso

---

## Passo 5 — Publicar no Vercel

1. No painel do Vercel, clique em **"Add New Project"**
2. Selecione o repositório `curriculo-ia`
3. Clique em **"Import"**
4. Em **"Environment Variables"** (variáveis de ambiente), adicione:
   - Nome: `VITE_ANTHROPIC_KEY`
   - Valor: sua chave da API Anthropic (veja abaixo como obter)
5. Clique em **"Deploy"**
6. Aguarde 2-3 minutos — o Vercel vai construir e publicar o site

---

## Como obter a chave da API Anthropic

A chave é necessária para a IA funcionar (adaptar currículos e gerar mensagens).

1. Acesse: https://console.anthropic.com
2. Crie uma conta gratuita
3. Vá em **"API Keys"**
4. Clique em **"Create Key"**
5. Copie a chave (começa com `sk-ant-...`)
6. Cole na variável `VITE_ANTHROPIC_KEY` no Vercel

---

## Resultado final

Após o deploy, o Vercel vai te dar um link como:
**https://curriculo-ia-seuusuario.vercel.app**

Esse é seu site funcionando na internet, de graça, para sempre.

---

## O que funciona agora vs. o que pode melhorar

### ✅ Funcionando agora:
- Cadastro completo do usuário
- Upload ou digitação do currículo
- Seleção de portais e preferências
- Currículo adaptado por IA para cada vaga
- Mensagem personalizada para o recrutador
- Painel de candidaturas com filtros
- Scores de Match e ATS

### 🔜 Próxima evolução (quando quiser):
- Vagas em tempo real via APIs (Gupy, Indeed, Jooble)
- Salvar candidaturas no banco de dados
- Exportar currículo adaptado em PDF
- Notificação por e-mail de novas vagas

---

## Dúvidas?

Se travar em qualquer etapa, me diga em qual passo parou
e eu te ajudo a resolver! 🙌
